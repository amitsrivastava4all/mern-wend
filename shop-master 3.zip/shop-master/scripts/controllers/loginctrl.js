import {AUTH} from '../utils/auth.js';
window.addEventListener('load', ()=>{
    document.querySelector('#login').addEventListener('click', login);
})
export function login(){
    AUTH.loginWithGmail();
}