import {initApp} from './productctrl.js';
window.addEventListener('load', bindDashBoardEvents);
function bindDashBoardEvents(){
    document.querySelector('#prodcrud').addEventListener('click', loadPage);
}
async function loadPage(){
    //alert("Load Page Call");
    const response= await fetch('http://127.0.0.1:5500/shop-master/product-crud2.html')
    const text = await response.text();
    document.querySelector('#root').innerHTML = text;
    console.log('text is ', text);
    initApp();
}