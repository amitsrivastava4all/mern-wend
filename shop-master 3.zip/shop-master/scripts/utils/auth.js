
export const AUTH = {
    loginWithGmail(){
        var provider = new firebase.auth.GoogleAuthProvider();
         provider.addScope('https://www.googleapis.com/auth/contacts.readonly');
        const promise = firebase.auth().signInWithPopup(provider);

        promise.then(result =>{
            console.log(result.user.displayName);
            localStorage.userName = result.user.displayName;
            location.href = 'http://127.0.0.1:5500/shop-master/dashboard.html';
        }).catch(err=>{
            console.log('Login fail ',err);
        })

    },
    loginWithFaceBook(){

    }
}