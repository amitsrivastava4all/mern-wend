import {db} from './firebase-config.js';
export const fireBaseOperations = {
    async add(product){
        const obj = {};
        for(let key in product){
            obj[key] = product[key];
        }
        const doc =await db.collection('products').add(obj);
        return doc;
    },
    async read(){
           const docs = await db.collection('products').get();
           return docs;
    }
}