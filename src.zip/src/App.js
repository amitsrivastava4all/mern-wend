import React from "react";

import './App.css';
import { Cards } from "./components/Cards";
import { Footer } from "./components/Footer";
import { Header } from "./components/Header";

function getStyle(){
  return {
    color:"red",
    backgroundColor:"green"
  }
}

function App(){
  return (<>
  <Header/>
  <Cards/>
  <Footer/>
  </>)
  //return (<><h1> Hello React JS </h1><h2>Hi React JS</h2></>);
  // return (<React.Fragment>
  //   <h1> Hello React JS </h1><h2>Hi React JS</h2>
  // </React.Fragment>);
  //return (<h1>Hello React JS</h1>) // this is a JSX
  // const h2 = React.createElement('h2', {className:'mycolor'}, 'Hi I am H2');
  // const h1 = React.createElement('h1',{style:getStyle()},'Hello React JS....');
  // //const h1 = React.createElement('h1',{style:{color:'red', backgroundColor:'yellow'}},'Hello React JS....');
  // return React.createElement('div',{},h1,h2);
  //return [h1, h2];
}
export default App;