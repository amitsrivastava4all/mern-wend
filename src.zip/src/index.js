import App from "./App";
import ReactDOM from 'react-dom';
import React from "react";
ReactDOM.render(<App/>, document.querySelector('#root'));
// Virtual DOM Connect to Real DOM

//const obj = React.createElement('h1',null,'Hello React Calling from index.js');
//console.log('type ', typeof obj);
//ReactDOM.render(obj,document.querySelector('#root'));