export const MenuItem = (props)=>{
    const mycolor = props.title =='Home'?'red':'blue';
    console.log(mycolor);
    const myStyle = {
        color : mycolor
    };
    return ( <li  className="nav-item">
    <a className="nav-link active"  style={myStyle} aria-current="page" href={props.link}>{props.title}</a>
  </li>);
}