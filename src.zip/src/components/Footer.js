import './Footer.css';
export function Footer(){
    const myStyle = {
        color:'red'

    };
    return (<div className ='footerstyle'>

        <h5 style={myStyle}>I am Footer</h5>
    </div>)
}