import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import { red } from "@mui/material/colors";
import Button from "@mui/material/Button";
import React, { useContext } from "react";
import store from "../store/shopstore";
import { useDispatch } from "react-redux";

import Avatar from "@mui/material/Avatar";
import { CartContext } from "../utils/provider/cart_context";
import { createAction } from "../actions/cartaction";
import { basketAdd } from "../reducers/cart_slice";
export const PizzaCard = ({ pizza }) => {
  const cartContext = useContext(CartContext);
  const dispatcher = useDispatch(); // Hook
  const addToCart = (pizza) => {
    cartContext.cartValue = cartContext.cartValue + 1;
    cartContext.updateCart();
    console.log("Cart Context ", cartContext);

    // New Way
    //const actionObject = createAction("BASKET_ADD", pizza);
    dispatcher(basketAdd(pizza));
    //Old way of  Calling Action
    /* console.log("Prepare Action...");
    const actionObject = createAction("BASKET_ADD", pizza);
    console.log("Now Dispatch ", actionObject);
    store.dispatch(actionObject); */
  };
  return (
    <Card sx={{ maxWidth: 345 }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
            P
          </Avatar>
        }
        title={pizza.name}
        subheader={pizza.menu_description}
      />
      <CardMedia
        component="img"
        height="194"
        image={pizza.assets.menu[0].url}
        alt="Paella dish"
      />
      <CardContent>
        <p>{pizza.price}</p>
        <Button
          onClick={() => {
            addToCart(pizza);
          }}
          variant="contained"
        >
          Add to Cart
        </Button>
      </CardContent>
    </Card>
  );
};
