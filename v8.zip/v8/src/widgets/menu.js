import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Link, NavLink } from "react-router-dom";
import { CartTotal } from "../components/CartTotal";
import { Constants } from "../utils/constants";
import "./menu.css";
export const Menu = () => {
  const getMenus = () => {
    const { ROUTES } = Constants;
    return [
      { name: "Home", link: ROUTES.HOME },
      { name: "Pizzas", link: ROUTES.PIZZAS },
      { name: "Desserts", link: `${ROUTES.DESSERTS}/30/June15` },
      { name: "Drinks", link: `${ROUTES.DRINKS}?price=100&type=cold` },
      { name: "Options", link: ROUTES.OPTIONS },
    ]; // replace with axios call (Menu JSON)
  };
  const myStyle = {
    color: "red",
  };
  return (
    <Box sx={{ display: "flex", alignItems: "center", textAlign: "center" }}>
      <CartTotal />
      {getMenus().map((menu, index) => (
        <Typography key={index} sx={{ minWidth: 100 }}>
          <NavLink exact activeStyle={myStyle} to={menu.link}>
            {/* <NavLink exact activeClassName="active" to={menu.link}> */}
            {menu.name}
          </NavLink>
        </Typography>
      ))}
      {/* <Typography sx={{ minWidth: 100 }}>Contact</Typography>
      <Typography sx={{ minWidth: 100 }}>Profile</Typography> */}
    </Box>
  );
};
