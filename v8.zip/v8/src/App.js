import logo from "./logo.svg";
import "./App.css";
import { Shop } from "./containers/Shop";

function App() {
  return <Shop />;
}

export default App;
