// Slice contain the small logic of bigger application
// Slice represent a reducer logic
import { createSlice } from "@reduxjs/toolkit";
const initialState = { pizzas: [] };
const cartSlice = createSlice({
  name: "cartSlice", // name of a slice
  initialState, // initialState of the pizza which is empty array
  reducers: {
    // Reducer contain all the operation which we do eariler using if else
    basketAdd(state, action) {
      console.log("State in Basked Add ", state, "Action is ", action);
      state.pizzas.push(action.payload); // Mutable
    },
  },
});
export const { basketAdd } = cartSlice.actions; // Slice give action no need to create an action
export default cartSlice.reducer; // Slice give reducer, this reducer will be use in store
