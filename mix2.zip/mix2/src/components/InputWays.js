import React from "react";
import logo from '../assets/logo.png';
export class Input extends React.Component{
    constructor(){
        super();
        console.log('Input ..... ', this.refs);
        this.name = React.createRef();
        this.age = React.createRef();
        this.address = React.createRef();
        this.price = React.createRef();
    }
    save(){
        console.log(this.name.current.value);
        console.log(this.age.current.value);
        console.log(this.address.current.value);
        console.log(this.price.current.value);
        // console.log(this.refs.name.value);
        // console.log(this.refs.age.value);
        // console.log(this.refs.address.value);
    }
    render(){
        return (<div>
            <img src={logo}/>
            {/* <img src = "https://reactjs.org/logo-og.png"/> */}
            <p>I am the Input Component</p>
            <input ref={this.name} type='text'  placeholder='Type Name Here'/>
            <input ref={this.age} type='text' placeholder='Type Age Here'/>
            <input ref={this.address} type='text' placeholder='Type Address Here'/>
            {/* <input min="1" max="100" type="range" onChange={(evt)=>{
                console.log('Value is ', evt.target.value);
            }}/> */}
             <input min="1" max="100" type="range" ref={this.price}/>
            <button onClick = {()=>{
                this.save();
            }}>Save</button>
            <hr/>
        </div>)
    }
}