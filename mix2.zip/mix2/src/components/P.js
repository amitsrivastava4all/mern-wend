import { C } from "./C";

export const P = ()=>{
    const X = (event)=>{
        let r = event.target.value;
        return r;
    }
    return (<C fn = {X}/>);

}