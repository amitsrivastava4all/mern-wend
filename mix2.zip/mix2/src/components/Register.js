export const Register = ()=>{
    return (<div>
        <h1>I am the Register</h1>
    </div>)
}