export const C = (props)=>{
    return (<input onChange = {(event)=>{
            let val = props.fn(event);
            console.log('Value is ', val);
    }} type = 'text' placeholder=''/>);
}