import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Button} from 'react-bootstrap';
import { Login } from './components/Login';
import { Register } from './components/Register';
import { Item } from './components/Item';
import { A } from './components/A';
import { B } from './components/B';
import { ThemeConsumer } from 'react-bootstrap/esm/ThemeProvider';
import { Input } from './components/InputWays';
class App extends React.Component{
  constructor(props){
    super(props); // Local Props pass to the parent props to initalize
    //super();
    console.log('Parent Props is ',this.props);
    console.log('Local Props is ', props);
    this.isLogin = true;
    this.name = '';
    this.items = [
      {id:1, name:'Mobile', price:8888},
      {id:2, name:'Tablet', price:4444},
      {id: 3, name:'LED', price:7766}
    ];
    this.state = {isLogin : this.isLogin, name:this.name};
  }
  showLoginOrRegiter(val){
     this.isLogin = val;
     this.setState({isLogin : this.isLogin});
  }
  takeName(event){
    let name = event.target.value;
    this.name  = name;
    this.setState({...this.state, name:this.name});

  }
  render(){
    console.log(this.props.children);
      return (
    <div className = 'container'>
      <Input/>
      <A fn = {this.takeName.bind(this)} name = {this.state.name}>

      <B name = {this.state.name}/>
      <B name = {this.state.name}/>
      <B name = {this.state.name}/>
      <B name = {this.state.name}/>


      </A>




      <p>Props Coming is {this.props.appName}</p>
           <Button onClick= {()=>{
             this.showLoginOrRegiter(true);
           }} variant="primary">Login {this.props.children} </Button> &nbsp;
           <Button onClick= {()=>{
             this.showLoginOrRegiter(false);
           }} variant="success">Register</Button>
           <hr/>
           {this.state.isLogin ?<Login/> : <Register/>}
           <hr/>
           {this.items.map((item, index)=>{
              return <Item key ={item.id}  name={item.name} price = {item.price}/>
           })}
    </div>
  )
  }
}
export default App;
// const App= ()=> {
//   return (
//     <div className = 'container'>
//            <Button variant="primary">Login</Button> &nbsp;
//            <Button variant="success">Register</Button>
//            <hr/>
//     </div>
//   )
// }

// export default App
