import Product from '../models/product.js';
export const productOperations = {
    products:[], // all product objects are store in product array
    getTotal(){
        return this.products.length;
    },
    removeMarked(){
        // remove all marked records permant
        //this.products = this.products.filter(product=> product.isMarkForDelete===false);
        this.products = this.products.filter(product=>!product.isMarkForDelete);
        return this.products;
    },
    toggleMarking(id){
        // Looking the id in array of objects
        let product = this.products.find(product=>product.id == id);
        if(product){
            product.toggle();
            // product.isMarkForDelete = !product.isMarkForDelete;
        }
    },
    getMarkTotal(){
        return this.products.filter(product=>product.isMarkForDelete).length;
    },
    getUnmarkTotal(){
        return this.getTotal() - this.getMarkTotal();
    },
    // add : function(){} (Key and Value)
    // ES6 Object ShortHand Style
    add(productParam){
        //let product = new Product(productParam['id'], productParam['name'], productParam['desc'],productParam['date'], productParam['url'], productParam['price']);
        let product = new Product();
        for(let key in productParam){
            product[key] = productParam[key];
        }
        this.products.push(product);
        return product;
    },

    search(){

    },
    update(){

    },
    sort(){

    }
}