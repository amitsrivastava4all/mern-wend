export const Button = ({doplus})=>{
    return (<button onClick={doplus} className ='btn btn-primary'>Plus</button>)
}