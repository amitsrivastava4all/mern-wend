// Function
export const Title = ()=>{
    return (<h1 className='alert-info text-center'>Counter App</h1>);
}