import { Title } from "../components/Title";
import React,{Component} from 'react';
import { Button } from "../components/Button";
import { Output } from "../components/Output";
export class Counter extends Component{
    constructor(){
        super(); // Parent class (Component) constructor call
        this.count = 0;
        this.state = {counter: this.count, x:10, y:20, z:30};
    }

    plus(){
        console.log('This is ',this);
        this.count++;
        //this.state.counter+++ // State Mutate No
        // State Immutable
        this.setState({...this.state, counter: this.count});
        //this.setState({counter:this.count});
        console.log('Count Value is ', this.count);
    }
    // Printing is because of render call
    render(){
        console.log('Render Start');
        // JSX (JavaScript and XML)
        return (<div className='container'>
                <Title/>
                <Button doplus ={this.plus.bind(this)}/>
                <Output result={this.state.counter}/>
                <p>X is {this.state.x}</p>
        </div>)
    }
}