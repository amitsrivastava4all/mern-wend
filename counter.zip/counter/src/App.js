import { Counter } from "./containers/Counter";

const App = ()=>{
  return (<Counter/>); // Calling Counter Container
}
export default App;