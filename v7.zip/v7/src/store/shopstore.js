import { createStore } from "redux";
import { cartReducer } from "../reducers/reducer";
const store = createStore(cartReducer);
store.subscribe(() => {
  console.log("State Update .... ", store.getState());
});
export default store;
