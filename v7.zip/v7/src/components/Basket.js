import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import { connect } from "react-redux";
const Basket = (props) => {
  //console.log("All Pizzas ", props.pizzas);
  return (
    <Box
      sx={{
        display: "flex",
        "& > :not(style)": {
          m: 1,
          width: 300,
          height: 500,
        },
      }}
    >
      <Paper elevation={4} variant="outlined" square>
        <h2>Your Basket</h2>
        <>
          {props.pizzas.map((pizza, index) => {
            console.log("Inside Map ", pizza);
            return (
              <p key={index}>
                {pizza.name} {pizza.price}
              </p>
            );
          })}
        </>
      </Paper>
    </Box>
  );
};
// Connect is coming from react - redux
// Redux state connect to the component props
// It need a function which is used to map Redux state to component props
const mapToState = (myState) => {
  console.log("Map to State Call ", myState);
  return {
    pizzas: myState.pizzas,
  };
};
export default connect(mapToState)(Basket);
