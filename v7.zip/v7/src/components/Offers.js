export const Offers = () => {
  return <p>Offers Avaliable</p>;
};
