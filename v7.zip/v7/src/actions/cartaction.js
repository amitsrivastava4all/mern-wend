export const createAction = (operationName, data) => {
  const cartAction = {
    type: operationName,
    payload: data,
  };
  return cartAction;
};
