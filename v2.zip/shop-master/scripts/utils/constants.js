const CONSTANTS = {
    EDIT_ICON : 'fa-pen-to-square',
    TRASH_ICON : 'fa-trash-can',
    SOLID :'fa-solid',
    MARGIN_RIGHT : 'me-2'

}