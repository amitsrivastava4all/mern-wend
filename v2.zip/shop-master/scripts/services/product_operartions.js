const productOperations = {
    products:[],
    getTotal(){
        return this.products.length;
    },
    mark(){
        return 0;
    },
    unmark(){
        return 0;
    },
    // add : function(){} (Key and Value)
    // ES6 Object ShortHand Style
    add(productParam){
        //let product = new Product(productParam['id'], productParam['name'], productParam['desc'],productParam['date'], productParam['url'], productParam['price']);
        let product = new Product();
        for(let key in productParam){
            product[key] = productParam[key];
        }
        this.products.push(product);
        return product;
    },
    remove(){

    },
    search(){

    },
    update(){

    },
    sort(){

    }
}