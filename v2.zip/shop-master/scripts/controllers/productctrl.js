// IO
window.addEventListener('load', initApp);
function initApp(){
    bindEvents();
    updateCounts();
}
function bindEvents(){
    document.getElementById('add').
    addEventListener('click', addProduct);
}
function addProduct(){
    const fields = ['id', 'name', 'desc', 'date','url','price'];
    const productObject = {};
    //for(var i = 0 ; i<fields.length; i++){
        for(let field of fields){
        productObject [field]= document.querySelector(`#${field}`).value;
    }
    console.log('Product Object ', productObject);
    let product = productOperations.add(productObject);
    printProduct(product);
    updateCounts();
    // var id = document.querySelector('#id').value;
    // var name = document.querySelector('#name').value;
    // var desc = document.querySelector('#desc').value;
}

function createIcon(className){
    // <i class="fa-solid fa-trash-can"></i>
    let icon = document.createElement('i');
    icon.className = `${CONSTANTS.SOLID} ${className} ${CONSTANTS.MARGIN_RIGHT}`;
    return icon;
}

function updateCounts(){
    document.querySelector('#total').innerText = productOperations.getTotal();
    document.querySelector('#mark').innerText = productOperations.mark();
    document.querySelector('#unmark').innerText = productOperations.unmark();
}

function printProduct(product){
    const tbody = document.querySelector('#products');
    const tr = tbody.insertRow();
    let index = 0;
    let td
    for(let key in product){
        td = tr.insertCell(index);
        td.innerText = product[key];
        index++;
    }
    td = tr.insertCell(index);
    td.appendChild(createIcon(CONSTANTS.TRASH_ICON));
    td.appendChild(createIcon(CONSTANTS.EDIT_ICON));
}