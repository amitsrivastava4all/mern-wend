 class Product{
    constructor(id, name, desc, date, url, price){
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.date = date;
        this.url = url;
        this.price = price;
        this.isMarkForDelete = false;
    }
    toggle(){
        this.isMarkForDelete = !this.isMarkForDelete;
    }
}
export default Product;