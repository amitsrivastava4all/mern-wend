export const Drinks = () => {
  return <h1>Drinks</h1>;
};
