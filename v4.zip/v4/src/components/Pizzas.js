export const Pizzas = () => {
  return <h1>Pizzas</h1>;
};
