import logo from './logo.svg';
import './App.css';
import { Greet } from './containers/Greet';

function App() {
  return (
   <Greet/>);
  }


export default App;
