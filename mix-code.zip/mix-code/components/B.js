export const B = ({name})=>{
    return (<p> I am the B Component {name}</p>)
}