export const Item = ({name, price})=>{
    return (<div>
        <p>Name is {name} and Price is {price}</p>
    </div>)
}