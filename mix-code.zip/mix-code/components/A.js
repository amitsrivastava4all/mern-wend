export const A = (props)=>{
    console.log('Children is ',props.children);

    return (
    <div>
        <input onChange = {(event)=>{
            props.fn(event);
        }} type='Type Your Name ' />
        <p> I am the A Component .......Children is {props.children.length}</p>
        <p>Props Access the Children.....</p>
        {props.children.map(child=>{
            console.log('Child is ', child.props);
            return child;
        })}
    </div>
    )
}