import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import { red } from "@mui/material/colors";
import Button from "@mui/material/Button";
import React, { useContext } from "react";

import Avatar from "@mui/material/Avatar";
import { CartContext } from "../utils/provider/cart_context";
export const PizzaCard = ({ pizza }) => {
  const cartContext = useContext(CartContext);
  const addToCart = () => {
    cartContext.cartValue = cartContext.cartValue + 1;
    cartContext.updateCart();
    console.log("Cart Context ", cartContext);
  };
  return (
    <Card sx={{ maxWidth: 345 }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
            P
          </Avatar>
        }
        title={pizza.name}
        subheader={pizza.menu_description}
      />
      <CardMedia
        component="img"
        height="194"
        image={pizza.assets.menu[0].url}
        alt="Paella dish"
      />
      <CardContent>
        <p>{pizza.price}</p>
        <Button onClick={addToCart} variant="contained">
          Add to Cart
        </Button>
      </CardContent>
    </Card>
  );
};
