import { NavLink, Route, Switch } from "react-router-dom";
import { Deals } from "./Deals";
import { Offers } from "./Offers";

export const Home = () => {
  return (
    <div>
      <h1>I am the Home Component</h1>
      <hr />
    </div>
  );
};
