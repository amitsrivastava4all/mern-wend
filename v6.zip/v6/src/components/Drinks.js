export const Drinks = (props) => {
  const getQueryParams = () => {
    const url = new URLSearchParams(queryParam);
    const obj = {};
    for (let e of url.entries()) {
      const key = e[0];
      const value = e[1];
      obj[key] = value;
    }
    return obj;
  };

  const queryParam = props.location.search;
  const obj = getQueryParams(queryParam);
  console.log("Query params is  ", queryParam);

  return (
    <h1>
      Drinks {obj["price"]} {obj["type"]}
    </h1>
  );
};
