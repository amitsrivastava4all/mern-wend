import React, { PureComponent } from "react";
import { getPizza, getPizza2 } from "../utils/api_client";
import Container from "@mui/material/Container";
import { PizzaCard } from "../widgets/card";
import load from "../assets/load.gif";
import { Menu } from "../widgets/menu";
import { routeMapping } from "../utils/routes/route_mapping";

export const Shop = () => {
  return (
    <Container maxWidth="sm">
      <Menu />
      <hr />
      {routeMapping()}
    </Container>
  );
};

/*
export class Shop extends PureComponent {
  constructor() {
    super();
    this.loading = true;
    this.state = { pizzas: [], loading: this.loading };
  }
  componentDidMount() {
    this.loadPizza();
  }
  componentWillUnmount() {
    // Clean Up Code
  }

  loadPizza() {
    const response = getPizza();
    // const response = getPizza2();
    response
      .then((res) => {
        this.loading = false;

        console.log("data is ", res.data["Vegetarian"]);
        this.setState({
          pizzas: res.data["Vegetarian"],
          loading: this.loading,
        });
        // localStorage.token = res.token;
      })
      .catch((err) => {
        console.log("Error is ", err);
      })
      .finally(() => {
        console.log("Always run ....");
      });
  }

  showPizza() {
    return this.state.pizzas.map((pizza, index) => (
      <PizzaCard pizza={pizza} key={index} />
    ));
  }
  // getRouting(name){
  //   if(name =='Pizzas'){
  //     return (<h1>I am the Pizza</h1>)
  //   }
  //   else
  //   if(name =='Desserts'){
  //     return (<h1>I am the Desserts</h1>)
  //   }
  //   else {
  //     return (<h1>I am the Drinks</h1>)
  //   }

  // }
  render() {
    console.log("Render Call ", this.state.loading);
    const loadingJSX = <img src={load} />;
    return (
      <Container maxWidth="sm">
        <Menu />
        <hr />
        {routeMapping()}
        {/* {this.state.loading ? loadingJSX : this.showPizza()} }
      // </Container>
   /* );
  }
}
*/
