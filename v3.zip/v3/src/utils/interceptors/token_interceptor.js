import axios from "axios";
export function loadInterceptor() {
  axios.interceptors.request.use((request) => {
    // axios.defaults.headers.common["Authorization"] = "A1111";
    // const cloneRequest = { ...request, x: 100 };
    // cloneRequest.headers["mydata"] = "A11111";
    // return cloneRequest;
    console.log("Interceptor Running...");
    return request;
  });
}
