import axios from "axios";
axios.defaults.baseURL = process.env.REACT_APP_BASEURL;

export const getPizza = () => {
  const URL = "/Pizza.json";
  //const response = axios.get(URL);
  const response = axios({
    // baseURL: process.env.REACT_APP_BASEURL,
    method: "GET",
    url: URL,
  });
  // axios.post(URL, {userid:'amit'})
  return response;
};

export const getPizza2 = () => {
  const axiosObject = axios.create({
    baseURL: "https://abcd.com",
    timeout: 3000,
  });
  const response = axiosObject.get("/Pizza.json");
  return response;
};
