import React, { PureComponent } from "react";
import { getPizza, getPizza2 } from "../utils/api_client";
import Container from "@mui/material/Container";
import { PizzaCard } from "../widgets/card";

export class Shop extends PureComponent {
  constructor() {
    super();
  }
  componentDidMount() {
    this.loadPizza();
  }
  componentWillUnmount() {
    // Clean Up Code
  }

  loadPizza() {
    const response = getPizza();
    // const response = getPizza2();
    response
      .then((res) => {
        console.log("data is ", res);
        // localStorage.token = res.token;
      })
      .catch((err) => {
        console.log("Error is ", err);
      })
      .finally(() => {
        console.log("Always run ....");
      });
  }

  render() {
    return (
      <Container maxWidth="sm">
        <PizzaCard />
        <PizzaCard />
        <PizzaCard />
      </Container>
    );
  }
}
