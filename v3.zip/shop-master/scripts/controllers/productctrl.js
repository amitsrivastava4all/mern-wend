// IO
window.addEventListener('load', initApp);
function initApp(){

    bindEvents();
    updateCounts();
    disableButtons();
}

function disableButtons(){
    document.querySelector('#delete').setAttribute('disabled', true);
}

const enableDeleteButton=()=>
    document.querySelector('#delete').removeAttribute('disabled');


function bindEvents(){
    document.getElementById('add').
    addEventListener('click', addProduct);
    document.querySelector('#delete').addEventListener('click', deleteProducts);
}
function deleteProducts(){
    // all red gone.
    let products = productOperations.removeMarked();
    printAllProducts(products);
}

function addProduct(){
    const fields = ['id', 'name', 'desc', 'date','url','price'];
    const productObject = {};
    //for(var i = 0 ; i<fields.length; i++){
        for(let field of fields){
        productObject [field]= document.querySelector(`#${field}`).value;
    }
    console.log('Product Object ', productObject);
    let product = productOperations.add(productObject);
    printProduct(product);
    updateCounts();
    // var id = document.querySelector('#id').value;
    // var name = document.querySelector('#name').value;
    // var desc = document.querySelector('#desc').value;
}

function createIcon(className, callBackFn, id){
    // <i class="fa-solid fa-trash-can"></i>
    let icon = document.createElement('i'); // Dynamic i tag
    icon.className = `${CONSTANTS.HAND} ${CONSTANTS.SOLID} ${className} ${CONSTANTS.MARGIN_RIGHT}`; // Dynamic class
    icon.addEventListener('click', callBackFn); // Dynamic Event Attach
    icon.setAttribute('pid', id); // Custom Attribute
    // icon object is calling a callBackFn when click event is happens
    // so icon object is become the current calling object and it access using this keyword
    // when click happens then this function will be invoke
    return icon;
}

function updateCounts(){
    document.querySelector('#total').innerText = productOperations.getTotal();
    let mark  = productOperations.getMarkTotal();
    document.querySelector('#mark').innerText = productOperations.getMarkTotal();
    document.querySelector('#unmark').innerText = productOperations.getUnmarkTotal();
    if(mark>0){
        enableDeleteButton();
        console.log('Enable....');
    }
    else{
        disableButtons();
    }
}

function toggleDelete(){
    console.log('Toggle Delete Call ', this);
    let icon = this;
    let id = icon.getAttribute('pid');
    productOperations.toggleMarking(id);
    console.log('ID is ',id);
    let tr =  icon.parentNode.parentNode;
    //tr.className = 'alert-danger';
    tr.classList.toggle('alert-danger');
    updateCounts();


    // Mark the Flag on each object

}

function edit(){
    console.log('Edit Call');
}

function printAllProducts(products){
    const tbody = document.querySelector('#products');
    tbody.innerHTML = '';
    products.forEach(printProduct);
    updateCounts();
   //products.forEach(product=>printProduct(product));



}

function printProduct(product){
    const tbody = document.querySelector('#products');
    const tr = tbody.insertRow();
    let index = 0;
    let td;
    let id = product['id'];
    for(let key in product){
        if(key == 'isMarkForDelete'){
            continue; // skip this key
        }
        td = tr.insertCell(index);
        td.innerText = product[key];
        index++;
    }
    td = tr.insertCell(index);
    td.appendChild(createIcon(CONSTANTS.TRASH_ICON, toggleDelete, id)); // we pass function as an argument
    td.appendChild(createIcon(CONSTANTS.EDIT_ICON, edit, id));
}