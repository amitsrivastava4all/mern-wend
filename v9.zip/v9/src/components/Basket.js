import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import { connect, useSelector } from "react-redux";
const Basket = (props) => {
  // useSelector is a react redux hook and it is doing the same stuff that maptoState done.
  const pizzas = useSelector((state) => {
    console.log("Pizza Loaded ", state.cartSlice.pizzas);
    return state.cartSlice.pizzas;
  });
  //console.log("All Pizzas ", props.pizzas);
  return (
    <Box
      sx={{
        display: "flex",
        "& > :not(style)": {
          m: 1,
          width: 300,
          height: 500,
        },
      }}
    >
      <Paper elevation={4} variant="outlined" square>
        <h2>Your Basket</h2>
        <>
          {!pizzas ? (
            <p>Loading....</p>
          ) : (
            pizzas.map((pizza, index) => {
              console.log("Inside Map ", pizza);
              return (
                <p key={index}>
                  {pizza.name} {pizza.price}
                </p>
              );
            })
          )}
          {/* {props.pizzas.map((pizza, index) => {
            console.log("Inside Map ", pizza);
            return (
              <p key={index}>
                {pizza.name} {pizza.price}
              </p>
            );
          })} */}
        </>
      </Paper>
    </Box>
  );
};
// Connect is coming from react - redux
// Redux state connect to the component props
// It need a function which is used to map Redux state to component props
/* This is Old Way of Getting the State in redux and map to the props
const mapToState = (myState) => {
  console.log("Map to State Call ", myState);
  return {
    pizzas: myState.pizzas,
  };
};
export default connect(mapToState)(Basket);
*/
export default Basket;
