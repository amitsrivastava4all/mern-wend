import { useSelector } from "react-redux";

export const Offers = () => {
  
  const offers = useSelector((state) => {
    console.log("Offers Loaded ", state.cartSlice);
    return state.cartSlice.offers;
  });
  return <p>Offers Avaliable {offers}</p>;
};
