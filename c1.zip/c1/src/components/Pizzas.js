import { getPizza } from "../utils/api_client";
import { useEffect, useState } from "react";
import load from "../assets/load.gif";
import { PizzaCard } from "../widgets/card";
import {useNavigate} from 'react-router-dom';
export const Pizzas = () => {
  let loading = true; // Local Variable
  const [pizzaState, setPizza] = useState({ pizzas: [], loading: loading });

  const showPizza = () => {
    return pizzaState.pizzas.map((pizza, index) => (
      <PizzaCard pizza={pizza} key={index} />
    ));
  };

  const loadPizza = () => {
    const response = getPizza();
    // const response = getPizza2();
    response
      .then((res) => {
        loading = false;

        console.log("data is ", res.data["Vegetarian"]);
        setPizza({ pizzas: res.data["Vegetarian"], loading: loading });
        // this.setState({
        //   pizzas: res.data["Vegetarian"],
        //   loading: this.loading,
        // });
        // localStorage.token = res.token;
      })
      .catch((err) => {
        console.log("Error is ", err);
      })
      .finally(() => {
        console.log("Always run ....");
      });
  };
  const nav = useNavigate();
  const moveToHome = ()=>{
     nav("/", {state:{name:'Amit', city:'Delhi'}});
  }

  useEffect(() => {
    console.log("I am the ComponentDidMount");
    loadPizza();
  }, []); // componentDidMount
  const loadingJSX = <img src={load} />;
  console.log("Pizza State ", pizzaState);
  return <><button onClick = {moveToHome}>Go to Home</button>{pizzaState.loading ? loadingJSX : showPizza()}</>;
  // return   {pizzaState.loading ? loadingJSX : showPizza()} ;
};
