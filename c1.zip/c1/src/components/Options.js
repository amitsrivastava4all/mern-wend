import { NavLink, Route } from "react-router-dom";
import { Deals } from "./Deals";
import { Offers } from "./Offers";

export const Options = () => {
  return (
    <>
      <NavLink to="/options/deals">Deals</NavLink> &nbsp;&nbsp;&nbsp;
      <NavLink to="/options/offers">Offers</NavLink>
      <br />
      <br />
      <br />
      <fieldset>
        <legend>Nested</legend>
        
        {/* <Route  path="/options/deals" element={<Deals/>} />
        <Route  path="/options/offers" element={<Offers/>} /> */}
      </fieldset>
    </>
  );
};
