import { NavLink, Route, Switch, useHistory, useLocation } from "react-router-dom";
import { Deals } from "./Deals";
import { Offers } from "./Offers";

export const Home = () => {
  //useHistory()
  const params = useLocation();
  console.log('Params are ',params);
  return (
    <div>
      <h1>I am the Home Component {params.state.name} {params.state.city}</h1>
      <hr />
    </div>
  );
};
