import { createAsyncThunk } from "@reduxjs/toolkit";

export const offerThunk = createAsyncThunk("offers", async ()=>{
    // Async Logic
    const offers = await getOffers();
    return offers;

})

const getOffers = ()=>{
    const promise = new Promise((resolve, reject)=>{
        setTimeout(()=>{
                resolve("10% off Offer");
        }, 7000);
    });
    return promise;
   
}