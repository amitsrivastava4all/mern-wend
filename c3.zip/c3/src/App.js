import logo from "./logo.svg";
import "./App.css";
import { Shop } from "./containers/Shop";
import { Component } from "react";
import ErrorBoundary from "./utils/components/error";
import {useState} from 'react';

function App() {
  const [count, setCount] = useState(0)
  const show = ()=>{
      console.log('I am the Show....');
      setCount(count+1);
      console.log('Count Value is ', count);
  }
  return( 
    <ErrorBoundary>
      <h1>Hello Shop</h1>
      <p data-testid="cvalue">{count}</p>
      <button data-testid="mybutton" onClick={show}>Click</button>
      {/* <Shop /> */}
  </ErrorBoundary>
  );
}
export default App;
