import { Component } from "react";

export default class ErrorBoundary extends Component{
    constructor(props){
        super(props);
        this.state = {errors:{}, isError:false};
    }
    componentDidCatch(error){
        this.setState( {errors: error, isError : true});
    }
    render(){
        return <>{this.state.isError?<p>OOPS Something Went Wrong...</p>: this.props.children}</>;
    }
}