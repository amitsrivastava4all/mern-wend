// Unit Test + Integeration Test
// TestCases - JEST

import {render, screen} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from './App';
describe('I am the Test Suite ', ()=>{
  test('should render Hello Shop', () => { 
    // Mocking
      render(<App/>);
      const element = screen.getByText("Hello Shop");
      // Assertion (Pass / Fail)
      expect(element).toBeInTheDocument();
   });
   test('should button click',()=>{
    render(<App/>);
    const button = screen.getByRole('button');
    //const button = screen.getByTestId('mybutton');
    console.log('Button is ', button);
    //button.click();
    userEvent.click(button); // Handle useState (Async)
    
    const pTag = screen.getByTestId('cvalue');
    expect(pTag).toHaveTextContent('1');
   })
});
