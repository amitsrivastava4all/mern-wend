// export const createAction = (operationName, data) => {
//   const cartAction = {
//     type: operationName,
//     payload: data,
//   };
//   return cartAction;
// };
// No Need in Redux ToolKit - My Slice will give actions
