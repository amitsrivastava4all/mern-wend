// Slice contain the small logic of bigger application
// Slice represent a reducer logic
import { createSlice } from "@reduxjs/toolkit";
import { offerThunk } from "../thunk/OfferThunk";
const initialState = { pizzas: [], offers:'' };
const cartSlice = createSlice({
  name: "cartSlice", // name of a slice
  initialState, // initialState of the pizza which is empty array
  reducers: {
    // Reducer contain all the operation which we do eariler using if else
    basketAdd(state, action) {
      console.log("State in Basked Add ", state, "Action is ", action);
      state.pizzas.push(action.payload); // Mutable
    },
  },
  extraReducers:{
   [offerThunk.pending]:(state, action)=>{
     state.offers = 'Offers Coming Soon';
   },
   [offerThunk.fulfilled]:(state, action)=>{
    state.offers = action.payload;
   },
   [offerThunk.rejected]:(state, action)=>{
    state.offers = 'Offer Rejected....';
   }

  }
});
export const { basketAdd } = cartSlice.actions; // Slice give action no need to create an action
export default cartSlice.reducer; // Slice give reducer, this reducer will be use in store
