export const Deals = () => {
  return <p>Deals Avaliable</p>;
};
