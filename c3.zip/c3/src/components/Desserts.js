import { useRef, useState } from "react";
import { useParams } from "react-router-dom";
export const Desserts = (props) => {
  //console.log("Props is ", props.match.params); // Old Way v5
  // const { discount, date } = props.match.params; // v5
  // v6
  const {discount, date} = useParams();
  const name = useRef("");
  const [dName, setName] = useState("");
  const takeName = (event) => {
    let val = event.target.value;
    console.log("Val ", val);
    setName(val);
  };
  const printName = () => {
    setName(name.current.value);
  };
  return (
    <div>
      <input
        type="text"
        ref={name}
        // onChange={takeName}
        placeholder="Type the Dessert u r looking for"
      />
      <button onClick={printName}>Search</button>
      <p>Your Name is {dName}</p>
      <h1>Desserts</h1>
      <p>Types of Desserts</p>
      <p>
        Discount {discount} Valid Till {date}
      </p>
      <ul>
        <li>Ice Cream</li>
      </ul>
    </div>
  );
};
