import { NavLink, Route, Switch, useHistory, useLocation } from "react-router-dom";
import { useApi } from "../utils/custom_hook";
import { Deals } from "./Deals";
import { Offers } from "./Offers";
import React,{useRef, useState} from 'react'
import { validateRegForm } from "../utils/validation";

export const Home = () => {
  //useHistory()
  const nameRef= useRef('');
  const phoneRef= useRef('');
  const params = useLocation();
  const [data] = useApi('https://gist.githubusercontent.com/prayagKhanal/8cdd00d762c48b84a911eca2e2eb3449/raw/5c5d62797752116799aacaeeef08ea2d613569e9/cakes.json')
  console.log('Params are ',params);
  const [errors, setError] = useState({});
   const customHookCaller = ()=>{
      console.log('Cakes Data ', data);
  }
  const validateName = (event)=>{
      let name = event.target.value;
      if(name.length ==0){
        setError({...errors, nameError:'Name is Empty'});
      }
      else if (name.length<=2){
        setError({...errors, nameError:'Name is Too Short'});
      } else if(name.length>=3 && name.length<=25){
        setError({...errors, nameError:''});
      }

  }
  const validatePhone = (event)=>{
    let phone = event.target.value;
    if(phone.length>10){
      event.preventDefault();
    }
    if(phone.length ==0){
      setError({...errors, phoneError:'Phone is Empty'});
    }
    else if (phone.length<=9){
      setError({...errors, phoneError:'Phone Number is Invalid'});
    } 
    else if(phone.length==10){
      setError({...errors, phoneError:''});
    }

}
const register = ()=>{
  const userInfo = {
    name: nameRef.current.value, phone : phoneRef.current.value
  }
  validateRegForm(userInfo);
}
  const errorStyle ={
    color:'red'
  };
 // e = f/100;
  return (
    <div>
      
      <button onClick = {customHookCaller}>Custom Hooks</button>
      <h1>I am the Home Component {params?.state?.name} {params?.state?.city}</h1>
      <label>Name</label>
      <input ref={nameRef} type='text' onChange={validateName} placeholder="Type Name Here"/>
      <span style={errorStyle}>{errors.nameError}</span>
      <br/>
      <label>Phone Number</label>
      <input ref={phoneRef} type='text' onKeyDown={validatePhone} placeholder="Type Phone Here"/>
      <span style={errorStyle}>{errors.phoneError}</span>
      <br/>
      <button onClick={register}>Register</button>
      <hr />
    </div>
  );
};
